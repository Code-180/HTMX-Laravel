<div class="container">
  <form hx-post="/blog/add" hx-encoding='multipart/form-data' id="form" hx-target="#result-message">
    <div id="result-message"></div>
    <div class="mb-3">
      <label for="blog_title" class="form-label">Blog Title</label>
      <input type="text" class="form-control" id="blog_title" name="blog_title">
    </div>
    <div class="mb-3">
      <label for="blog_description" class="form-label">Blog Description</label>
      <textarea class="form-control" id="blog_description" name="blog_description" rows="3"></textarea>
    </div>
    <div class="mb-3">
      <label for="blog_tag" class="form-label">Blog Tags</label>
      <input type="text" class="form-control" id="blog_tag" name="blog_tag">
    </div>
    <div class="mb-3">
      <label for="blog_file" class="form-label">Picture</label>
      <input type="file" class="form-control" id="image" name="image">
    </div>
    <button class="btn btn-success">Save</button>
    <button type="button" class="btn btn-info" onclick="restBlog()">Cancel</button>
    <progress id='progress' value='0' max='100'></progress>
  </form>
</div>
<script>
  htmx.on('#form', 'htmx:xhr:progress', function(evt) {
    htmx.find('#progress').setAttribute('value', evt.detail.loaded/evt.detail.total * 100)
  });
</script>
<?php /**PATH D:\laragon\www\Youtube\AlgoliaSearch\resources\views/data_view/blog_add.blade.php ENDPATH**/ ?>