<?php if($status == true): ?>
<table class="table table-bordered">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Title</th>
        <th scope="col">Description</th>
        <th scope="col">Tag</th>
        <th scope="col">Created At</th>
        <th scope="col">Updated At</th>
        <th scope="col">Edit</th>
        <th scope="col">Delete</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($single->id); ?></th>
        <td><?php echo e($single->blog_title); ?></td>
        <td><?php echo e($single->blog_description); ?></td>
        <td><?php echo e($single->blog_tag); ?></td>
        <td><?php echo e($single->created_at); ?></td>
        <td><?php echo e($single->updated_at); ?></td>
        <td><button type="button" class="btn btn-success" hx-get="/blog/list" hx-target="#result">Edit</button></td>
        <td><button type="button" class="btn btn-danger" hx-get="/blog/list" hx-target="#result">Delete</button></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<?php endif; ?>
<?php /**PATH D:\laragon\www\Youtube\AlgoliaSearch\resources\views/data_view/blog_data.blade.php ENDPATH**/ ?>