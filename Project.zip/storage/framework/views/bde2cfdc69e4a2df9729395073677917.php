<div class="container">
  <form hx-post="/blog/update" hx-target="#result-message" hx-encoding='multipart/form-data' id="form_update">
    <input type="hidden" id="id" name="id" value="<?php echo e($update->id); ?>">
    <div id="result-message"></div>
    <div class="mb-3">
      <label for="blog_title" class="form-label">Blog Title</label>
      <input type="text" class="form-control" id="blog_title" name="blog_title" value="<?php echo e($update->blog_title); ?>">
    </div>
    <div class="mb-3">
      <label for="blog_description" class="form-label">Blog Description</label>
      <textarea class="form-control" id="blog_description" name="blog_description" rows="3"><?php echo e($update->blog_description); ?></textarea>
    </div>
    <div class="mb-3">
      <label for="blog_tag" class="form-label">Blog Tags</label>
      <input type="text" class="form-control" id="blog_tag" name="blog_tag" value="<?php echo e($update->blog_tag); ?>">
    </div>
    <div class="mb-3">
      <label for="blog_file" class="form-label">Picture</label>
      <input type="file" class="form-control" id="image" name="image">
    </div>
    <button class="btn btn-success">Update</button>
    <button type="button" class="btn btn-info" onclick="restBlog()">Cancel</button>
    <progress id='progress' value='0' max='100'></progress>
  </form>
</div>
<script>
  htmx.on('#form_update', 'htmx:xhr:progress', function(evt) {
    htmx.find('#progress').setAttribute('value', evt.detail.loaded/evt.detail.total * 100)
  });
</script>
<?php /**PATH D:\laragon\www\Youtube\Project\resources\views/data_view/blog_update.blade.php ENDPATH**/ ?>