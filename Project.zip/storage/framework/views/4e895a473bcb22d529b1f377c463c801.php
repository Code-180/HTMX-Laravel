<?php if($status == true): ?>
<table class="table table-bordered">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Title</th>
        
        <th scope="col">Tag</th>
        <th scope="col">Created At</th>
        <th scope="col">Updated At</th>
        <th scope="col">Edit</th>
        <th scope="col">Delete</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($single->id); ?></th>
        <td><?php echo e($single->blog_title); ?></td>
        
        <td><?php echo e($single->blog_tag); ?></td>
        <td><?php echo e($single->created_at); ?></td>
        <td><?php echo e($single->updated_at); ?></td>
        <td><button type="button" class="btn btn-success" hx-indicator="#loader" hx-get="/blog/update-view/<?php echo e($single->id); ?>" hx-target="#add-edit">Edit</button></td>
        <td><button type="button" class="btn btn-danger" hx-indicator="#loader" hx-get="/blog/delete/<?php echo e($single->id); ?>" hx-target="#add-edit" hx-confirm="Are you sure you wish to delete this ?">Delete</button></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<?php endif; ?>
<?php /**PATH D:\laragon\www\Youtube\AlgoliaSearch\resources\views/data_view/blog_list.blade.php ENDPATH**/ ?>