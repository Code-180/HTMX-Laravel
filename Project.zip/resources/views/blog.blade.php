@extends('main')
@section('content')
<div class="container">
  <div class="row">
    <div class="col-md-10 mb-3 mt-3">
      <h3>Blog</h3>
    </div>
    <div class="col-md-2 mb-3 mt-3">
      <button type="button" class="btn btn-primary" hx-get="/blog/add-view" hx-indicator="#loader" hx-target="#add-edit">Add</button>
      <button type="button" class="btn btn-info" id="firstBtn" hx-get="/blog/list" hx-indicator="#loader" hx-target="#result">Refresh</button>
    </div>
  </div>
  <div class="alert alert-warning htmx-indicator" id="loader">Loding........</div>
  <div id="add-edit" class="mb-3 mt-3"></div>
  <div id="result"></div>
</div>
@stop
