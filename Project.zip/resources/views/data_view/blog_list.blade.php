@if ($status == true)
<table class="table table-bordered">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Title</th>
        {{-- <th scope="col">Description</th> --}}
        <th scope="col">Tag</th>
        <th scope="col">Created At</th>
        <th scope="col">Updated At</th>
        <th scope="col">Edit</th>
        <th scope="col">Delete</th>
      </tr>
    </thead>
    <tbody>
      @foreach ($response as $single)
      <tr>
        <th scope="row">{{ $single->id }}</th>
        <td>{{ $single->blog_title }}</td>
        {{-- <td>{{ $single->blog_description }}</td> --}}
        <td>{{ $single->blog_tag }}</td>
        <td>{{ $single->created_at }}</td>
        <td>{{ $single->updated_at }}</td>
        <td><button type="button" class="btn btn-success" hx-indicator="#loader" hx-get="/blog/update-view/{{ $single->id }}" hx-target="#add-edit">Edit</button></td>
        <td><button type="button" class="btn btn-danger" hx-indicator="#loader" hx-get="/blog/delete/{{ $single->id }}" hx-target="#add-edit" hx-confirm="Are you sure you wish to delete this ?">Delete</button></td>
      </tr>
      @endforeach
    </tbody>
  </table>
@endif
