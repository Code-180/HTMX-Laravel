function restCreateBlog() 
{
	return document.getElementById('result-add').innerHTML = '';
}