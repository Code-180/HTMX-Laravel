<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Products extends Authenticatable
{
    //use Searchable;
    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'product_title',
        'product_description',
        'product_price',
        'product_discount_price',
    ];
}
