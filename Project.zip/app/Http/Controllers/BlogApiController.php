<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use Illuminate\Http\Request;
use Validator;

class BlogApiController extends Controller
{
    public function __construct()
    {
        //$this->middleware('auth');
    }
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    /**
     * @queryParam
     */
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public function list(Request $request)
    {
        //++++++++++++++++++++++++++++++++++++++++++++++
        $respond = [];
        //++++++++++++++++++++++++++++++++++++++++++++++
        try {
            //++++++++++++++++++++++++++++++++++++++++++++++
            $obj = Blog::all();
            //++++++++++++++++++++++++++++++++++++++++++++++
            $respond['status']   = true;
            $respond['message']  = 'Get';
            $respond['response'] = $obj;
        } catch (\Exception $e) {
            $respond['status']        = false;
            $respond['message']       = $e->getMessage();
            $respond['response_data'] = null;
        }
        return $respond;
    }
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    /**
     * @queryParam
     */
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public function searching(Request $request)
    {
        //++++++++++++++++++++++++++++++++++++++++++++++
        $respond = [];
        //++++++++++++++++++++++++++++++++++++++++++++++
        try {
            //++++++++++++++++++++++++++++++++++++++++++++++
            $obj = Blog::search($request->title)->get();
            //++++++++++++++++++++++++++++++++++++++++++++++
            $respond['status']   = true;
            $respond['message']  = 'Search';
            $respond['response'] = $obj;
        } catch (\Exception $e) {
            $respond['status']        = false;
            $respond['message']       = $e->getMessage();
            $respond['response_data'] = null;
        }
        return $respond;
    }
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    /**
     * @queryParam
     */
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public function add(Request $request)
    {
        //++++++++++++++++++++++++++++++++++++++++++++++
        $respond = [];
        //++++++++++++++++++++++++++++++++++++++++++++++
        $validator = Validator::make($request->all(), [
            'blog_title'       => 'required',
            'blog_description' => 'required',
            'blog_tag'         => 'required',
        ]);
        //++++++++++++++++++++++++++++++++++++++++++++++
        if ($validator->fails()) {
            $respond['status']        = false;
            $respond['message']       = 'Validation Error';
            $respond['response_data'] = $validator->messages();
        } else {
            try {
                //+++++++++++++++++++++++++++++++++++++++++++++++++++++
                $obj = new Blog;
                //+++++++++++++++++++++++++++++++++++++++++++++++++++++
                $obj->blog_title       = $request->blog_title;
                $obj->blog_description = $request->blog_description;
                $obj->blog_tag         = $request->blog_tag;
                //++++++++++++++++++++++++++++++++++++++++++++++++++++++
                $obj->save();
                //++++++++++++++++++++++++++++++++++++++++++++++++++++++
                $respond['status']   = true;
                $respond['message']  = 'Successfully added.';
                $respond['response'] = Blog::find($obj->id);
            } catch (\Exception $e) {
                $respond['status']        = false;
                $respond['message']       = $e->getMessage();
                $respond['response_data'] = null;
            }
        }
        return $respond;
    }
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    /**
     * @queryParam
     */
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public function update(Request $request)
    {
        //++++++++++++++++++++++++++++++++++++++++++++++
        $respond = [];
        //++++++++++++++++++++++++++++++++++++++++++++++
        $validator = Validator::make($request->all(), [
            'id'               => 'required',
            'blog_title'       => 'required',
            'blog_description' => 'required',
            'blog_tag'         => 'required',
            'blog_image'       => 'required',
        ]);
        //++++++++++++++++++++++++++++++++++++++++++++++
        if ($validator->fails()) {
            $respond['status']        = false;
            $respond['message']       = 'Validation Error';
            $respond['response_data'] = $validator->messages();
        } else {
            try {
                //+++++++++++++++++++++++++++++++++++++++++++++++++++++
                $obj = Blog::find($request->id);
                //+++++++++++++++++++++++++++++++++++++++++++++++++++++
                $obj->blog_title       = $request->blog_title;
                $obj->blog_description = $request->blog_description;
                $obj->blog_tag         = $request->blog_tag;
                //++++++++++++++++++++++++++++++++++++++++++++++++++++++
                $obj->save();
                //++++++++++++++++++++++++++++++++++++++++++++++++++++++
                $respond['status']   = true;
                $respond['message']  = 'Successfully updated.';
                $respond['response'] = Blog::find($obj->id);
            } catch (\Exception $e) {
                $respond['status']        = false;
                $respond['message']       = $e->getMessage();
                $respond['response_data'] = null;
            }
        }
        return $respond;
    }
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    /**
     * @queryParam
     */
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public function destroy(Request $request)
    {
        //++++++++++++++++++++++++++++++++++++++++++++++
        $respond = [];
        //++++++++++++++++++++++++++++++++++++++++++++++
        $validator = Validator::make($request->all(), [
            'id' => 'required',
        ]);
        //++++++++++++++++++++++++++++++++++++++++++++++
        if ($validator->fails()) {
            $respond['status']        = false;
            $respond['message']       = 'Validation Error';
            $respond['response_data'] = $validator->messages();
        } else {
            try {
                //++++++++++++++++++++++++++++++++++++++++++
                Blog::destroy($request->id);
                //++++++++++++++++++++++++++++++++++++++++++
                $respond['status']   = true;
                $respond['message']  = 'Successfully deleted.';
                $respond['response'] = null;
            } catch (\Exception $e) {
                $respond['status']        = false;
                $respond['message']       = $e->getMessage();
                $respond['response_data'] = null;
            }
        }
        return $respond;
    }
//End
}
