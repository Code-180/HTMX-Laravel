<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use Illuminate\Http\Request;
use Validator;

class BlogController extends Controller
{
    public function __construct()
    {
        //$this->middleware('auth');
    }
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    /**
     * @queryParam
     */
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public function add_view(Request $request)
    {
        try {
            return view('data_view.blog_add');
        } catch (\Exception $e) {
            return "<div class='alert alert-danger'>'" . $e->getMessage() . "'</div>";
        }

    }
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    /**
     * @queryParam
     */
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public function update_view($id)
    {
        try {
            $obj = Blog::find($id);
            return view('data_view.blog_update')->with('update', $obj);
        } catch (\Exception $e) {
            return "<div class='alert alert-danger'>'" . $e->getMessage() . "'</div>";
        }

    }
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    /**
     * @queryParam
     */
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public function list(Request $request)
    {
        //++++++++++++++++++++++++++++++++++++++++++++++
        $respond = [];
        //++++++++++++++++++++++++++++++++++++++++++++++
        try {
            //++++++++++++++++++++++++++++++++++++++++++++++
            $obj = Blog::all();
            //++++++++++++++++++++++++++++++++++++++++++++++
            $respond['status']   = true;
            $respond['message']  = 'Get';
            $respond['response'] = $obj;
        } catch (\Exception $e) {
            $respond['status']        = false;
            $respond['message']       = $e->getMessage();
            $respond['response_data'] = null;
        }
        return view('data_view.blog_list', $respond);
    }
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    /**
     * @queryParam
     */
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public function add(Request $request)
    {
        //++++++++++++++++++++++++++++++++++++++++++++++
        $respond = [];
        //++++++++++++++++++++++++++++++++++++++++++++++
        $validator = Validator::make($request->all(), [
            'blog_title'       => 'required',
            'blog_description' => 'required',
            'blog_tag'         => 'required',
        ]);
        //++++++++++++++++++++++++++++++++++++++++++++++
        if ($validator->fails()) {
            return view('data_view.error_data', [
                'errors' => $validator->errors(),
            ]);
        } else {
            try {
                //+++++++++++++++++++++++++++++++++++++++++++++++++++++
                $obj = new Blog;
                //+++++++++++++++++++++++++++++++++++++++++++++++++++++
                $obj->blog_title       = $request->blog_title;
                $obj->blog_description = $request->blog_description;
                $obj->blog_tag         = $request->blog_tag;
                //++++++++++++++++++++++++++++++++++++++++++++++++++++++
                if ($request->hasFile('image')) {
                    $image           = $request->file('image');
                    $file_document   = time() . '.' . $image->getClientOriginalExtension();
                    $destinationPath = public_path('/upload');
                    $image->move($destinationPath, $file_document);
                    $obj->blog_image = $file_document;
                }
                //++++++++++++++++++++++++++++++++++++++++++++++++++++++
                $obj->save();
                //++++++++++++++++++++++++++++++++++++++++++++++++++++++
                return "<div class='alert alert-success'>Successfully Added.</div>";
            } catch (\Exception $e) {
                return "<div class='alert alert-danger'>'" . $e->getMessage() . "'</div>";
            }
        }
    }
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    /**
     * @queryParam
     */
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public function update(Request $request)
    {
        //++++++++++++++++++++++++++++++++++++++++++++++
        $respond = [];
        //++++++++++++++++++++++++++++++++++++++++++++++
        $validator = Validator::make($request->all(), [
            'id'               => 'required',
            'blog_title'       => 'required',
            'blog_description' => 'required',
            'blog_tag'         => 'required',
        ]);
        //++++++++++++++++++++++++++++++++++++++++++++++
        if ($validator->fails()) {
            return view('data_view.error_data', [
                'errors' => $validator->errors(),
            ]);
        } else {
            try {
                //+++++++++++++++++++++++++++++++++++++++++++++++++++++
                $obj = Blog::find($request->id);
                //+++++++++++++++++++++++++++++++++++++++++++++++++++++
                $obj->blog_title       = $request->blog_title;
                $obj->blog_description = $request->blog_description;
                $obj->blog_tag         = $request->blog_tag;
                //++++++++++++++++++++++++++++++++++++++++++++++++++++++
                if ($request->hasFile('image')) {
                    $image           = $request->file('image');
                    $file_document   = time() . '.' . $image->getClientOriginalExtension();
                    $destinationPath = public_path('/upload');
                    $image->move($destinationPath, $file_document);
                    $obj->blog_image = $file_document;
                }
                //++++++++++++++++++++++++++++++++++++++++++++++++++++++
                $obj->save();
                //++++++++++++++++++++++++++++++++++++++++++++++++++++++
                return "<div class='alert alert-success'>Successfully Updated.</div>";
            } catch (\Exception $e) {
                return "<div class='alert alert-danger'>'" . $e->getMessage() . "'</div>";
            }
        }
        return $respond;
    }
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    /**
     * @queryParam
     */
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public function destroy($id)
    {
        try {
            //++++++++++++++++++++++++++++++++++++++++++
            Blog::destroy($id);
            //++++++++++++++++++++++++++++++++++++++++++
            return "<div class='alert alert-success'>Successfully Deleted.</div>";
        } catch (\Exception $e) {
            return "<div class='alert alert-danger'>'" . $e->getMessage() . "'</div>";
        }
    }
//End
}
